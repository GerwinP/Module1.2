package utils;

public enum PlayerColor {
	RED, YELLOW, EMPTY;
}
