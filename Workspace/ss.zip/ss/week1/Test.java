package ss.week1;

public class Test {
	public static void main(String[] args){
		PasswordTest test = new PasswordTest();
		test.runTest();
	}
}
