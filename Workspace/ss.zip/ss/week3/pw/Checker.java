package ss.week3.pw;

public interface Checker {
	
	public boolean acceptable(String suggestion);
	
	public String generatePass();
}
