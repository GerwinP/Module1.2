package ss.week7.threads;

/**
 * Interface used in Producer/Consumer program.
 */
public interface IntCell {
	public void setValue(int val);
	public int getValue();
}
