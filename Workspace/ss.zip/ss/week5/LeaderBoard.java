package ss.week5;

import java.util.LinkedList;

public class LeaderBoard {
	
	public static void addNewScore (Player p, int s){
		LinkedList<LinkedList<String>> scores = new LinkedList<LinkedList<String>>();
		LinkedList<String> newScore = new LinkedList<String>();
		newScore.add();
		
		scores.add(newScore);
	}

}
